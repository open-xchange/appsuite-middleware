package com.hazelcast.spring.serialization;

/**
 * @author mdogan 02/12/13
 */
public class DummySerializableObject2 {

}
