<script type="text/javascript">
      var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
      document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
  </script>
  <script type="text/javascript">
      try {
      var pageTracker = _gat._getTracker("UA-3921306-1");
      pageTracker._trackPageview();
      } catch(err) {
      }
  </script>

  <script type="text/javascript">
    window.AIConfig = {};
    window.AIConfig.accountId='hazelcast';
    window.AIConfig.mailTextField = 'email';
    window.AIConfig.mailButton = 'submit';
    var protocol = (("https:" == document.location.protocol) ? "https:" : "http:");
    document.write(unescape("%3Cscript src='"+protocol+"//cloud2.insightera.com/gw1/djs' type='text/javascript'%3E%3C/script%3E"));
  </script>
  <script type="text/javascript">
      function download(file) {
      var target = "/hazelcast/download/" + file;
      var pageTracker = _gat._getTracker("UA-3921306-1");
      pageTracker._trackPageview(target);
      }
  </script>

   <!-- Google Code for Remarketing Tag --> 
    <script type="text/javascript">
        /* <![CDATA[ */
        var google_conversion_id = 980562137;
        var google_custom_params = window.google_tag_params;
        var google_remarketing_only = true;
        /* ]]> */
        </script>
        <script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
    </script>
    <noscript>
        <div style="display:inline;">
        <img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/980562137/?value=0&amp;guid=ON&amp;script=0"/>
        </div>
    </noscript>