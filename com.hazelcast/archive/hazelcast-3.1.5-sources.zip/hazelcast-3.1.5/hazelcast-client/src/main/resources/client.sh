#!/bin/sh

java -Djava.net.preferIPv4Stack=true -jar ../lib/hazelcast-client-${project.version}.jar

