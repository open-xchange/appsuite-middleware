package org.ho.yaml.tests;

public class UnionSet {
	   public int dim;
	   public int[][][] constraints;
	}
