Fitnesse - www.fitnesse.org
The fully integrated standalone wiki, and acceptance testing framework.
-----------------------------------------------------------------------

REQUIREMENTS:
Java 1.5 or newer.
java.exe (Windows) or java (other OS's) must be in the system path.

INSTALATION:
Unzip distribution to a reasonable location.

RUNNING FITNESSE:
     cd fitnesse
     java -jar fitnesse.jar

Convenience Scripts to start FitNesse
 Windows:
    Double-click run.bat.

 Unix, Linux, Mac OS X:
    make run
    ./run

If port 80 is already in use or restricted, run with the arguments 
"-p number", where "number" is an open port number (e.g., 8080).

USAGE:
Navigate to the installation machine in you browser of choice.
If this is the installation machine use http://localhost or
http://localhost:number, if not using port 80.

Enjoy!

    unclebob@@objectmentor.com

Please visit fitnesse.org for questions or comments.




