// Copyright (C) 2003,2004,2005 by Object Mentor, Inc. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package eg.employeePayroll;

import fitnesse.fixtures.RowEntryFixture;

import java.util.Date;

public class PayDay extends RowEntryFixture {
  public Date payDate;
  public int checkNumber;

  public void enterRow() throws Exception {

  }
}
