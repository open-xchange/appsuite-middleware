package fitnesse.slim.test;

public class DummyDecisionTableWithExecuteButNoReset {
  public void execute() {};
  public String x() {return "";}
}
