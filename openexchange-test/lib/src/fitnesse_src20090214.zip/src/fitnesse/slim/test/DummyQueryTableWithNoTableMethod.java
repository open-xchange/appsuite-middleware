package fitnesse.slim.test;

import fitnesse.wikitext.Utils;
import static fitnesse.util.ListUtility.*;

import java.util.List;

public class DummyQueryTableWithNoTableMethod {
  public List<Object> query() {
    return list();
  }
}
