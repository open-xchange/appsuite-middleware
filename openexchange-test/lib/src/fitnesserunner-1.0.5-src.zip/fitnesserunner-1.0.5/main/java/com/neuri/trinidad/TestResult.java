package com.neuri.trinidad;

import fit.Counts;

public interface TestResult {
	 Counts getCounts();
	 String getName();
	 String getContent();	
}
