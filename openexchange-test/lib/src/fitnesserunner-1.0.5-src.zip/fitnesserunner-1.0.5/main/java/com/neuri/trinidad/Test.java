package com.neuri.trinidad;

public interface Test {
	String getName();
	String getContent();
}
