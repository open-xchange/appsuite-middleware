package com.neuri.trinidad;

public interface TestEngine {
	public TestResult runTest(Test test);
}
