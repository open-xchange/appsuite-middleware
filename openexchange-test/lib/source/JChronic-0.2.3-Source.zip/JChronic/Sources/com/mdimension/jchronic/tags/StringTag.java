package com.mdimension.jchronic.tags;

public class StringTag extends Tag<String> {
  public StringTag(String type) {
    super(type);
  }
}
