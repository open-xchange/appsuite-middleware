package javapns.json;

public class JSONNull implements JSONRawValue {

	@Override
	public String toString() {
		return "null";
	}

}
