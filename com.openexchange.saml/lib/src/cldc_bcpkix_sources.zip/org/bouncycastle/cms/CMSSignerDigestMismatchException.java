package org.bouncycastle.cms;

public class CMSSignerDigestMismatchException
    extends CMSException
{
    public CMSSignerDigestMismatchException(
        String msg)
    {
        super(msg);
    }
}
