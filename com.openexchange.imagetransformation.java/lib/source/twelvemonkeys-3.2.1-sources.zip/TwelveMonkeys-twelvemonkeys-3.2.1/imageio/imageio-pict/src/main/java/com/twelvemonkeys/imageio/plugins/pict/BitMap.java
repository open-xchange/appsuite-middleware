package com.twelvemonkeys.imageio.plugins.pict;

/**
 * BitMap.
 *
 * @author <a href="mailto:harald.kuhr@gmail.com">Harald Kuhr</a>
 * @author last modified by $Author: harald.kuhr$
 * @version $Id: BitMap.java,v 1.0 20/02/15 harald.kuhr Exp$
 */
final class BitMap {
}
