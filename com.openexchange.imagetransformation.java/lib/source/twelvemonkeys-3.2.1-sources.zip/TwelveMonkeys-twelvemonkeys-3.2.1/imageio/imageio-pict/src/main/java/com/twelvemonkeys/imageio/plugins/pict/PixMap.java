package com.twelvemonkeys.imageio.plugins.pict;

/**
 * PixMap.
 *
 * @author <a href="mailto:harald.kuhr@gmail.com">Harald Kuhr</a>
 * @author last modified by $Author: harald.kuhr$
 * @version $Id: PixMap.java,v 1.0 20/02/15 harald.kuhr Exp$
 */
final class PixMap {
}
