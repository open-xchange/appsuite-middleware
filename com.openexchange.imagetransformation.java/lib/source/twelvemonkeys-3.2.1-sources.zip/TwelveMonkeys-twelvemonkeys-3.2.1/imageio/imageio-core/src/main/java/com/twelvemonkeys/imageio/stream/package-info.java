/**
 * Provides various additional stream implementations.
 */
package com.twelvemonkeys.imageio.stream;