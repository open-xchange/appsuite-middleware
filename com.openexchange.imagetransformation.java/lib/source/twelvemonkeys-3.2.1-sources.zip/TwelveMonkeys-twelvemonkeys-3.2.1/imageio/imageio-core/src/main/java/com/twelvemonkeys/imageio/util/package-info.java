/**
 * Provides various common utilities for reading and writing images.
 */
package com.twelvemonkeys.imageio.util;