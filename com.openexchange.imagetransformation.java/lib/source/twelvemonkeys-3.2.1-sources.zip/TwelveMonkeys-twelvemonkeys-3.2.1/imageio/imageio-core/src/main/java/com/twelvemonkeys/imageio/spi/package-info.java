/**
 * Provides helper classes for service provider implementations.
 */
package com.twelvemonkeys.imageio.spi;