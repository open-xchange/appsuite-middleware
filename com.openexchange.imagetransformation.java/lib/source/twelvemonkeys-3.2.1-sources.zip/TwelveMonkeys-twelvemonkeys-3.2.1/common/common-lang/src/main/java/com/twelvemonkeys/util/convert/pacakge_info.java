/**
 * Provides a general purpose conversion framework, for conversion of values
 * between string representations and objects.
 */
package com.twelvemonkeys.util.convert; 