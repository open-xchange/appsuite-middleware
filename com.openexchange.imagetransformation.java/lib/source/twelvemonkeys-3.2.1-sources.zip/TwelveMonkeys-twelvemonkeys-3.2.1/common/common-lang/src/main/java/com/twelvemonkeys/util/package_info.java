/**
 * Provides miscellaneous utility classes.
 */
package com.twelvemonkeys.util;