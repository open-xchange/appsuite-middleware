/**
 * Provides functionality for regular expressions.
 */
package com.twelvemonkeys.util.regex;