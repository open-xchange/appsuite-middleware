package com.twelvemonkeys.util.convert;

import junit.framework.TestCase;

/**
 * ConverterTestCase
 * <p/>
 *
 * @author <a href="mailto:harald.kuhr@gmail.com">Harald Kuhr</a>
 * @author last modified by $Author: haku $
 * @version $Id: //depot/branches/personal/haraldk/twelvemonkeys/release-2/twelvemonkeys-core/src/test/java/com/twelvemonkeys/util/convert/ConverterTestCase.java#1 $
 */
public class ConverterTestCase extends TestCase {

    public void testMe() {
        // TODO: Implement tests
    }
}
