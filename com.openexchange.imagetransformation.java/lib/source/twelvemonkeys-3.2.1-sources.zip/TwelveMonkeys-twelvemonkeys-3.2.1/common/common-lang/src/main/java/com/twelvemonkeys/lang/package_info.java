/**
 *Contains utils/helpers for classes in {@code java.lang}.
 */
package com.twelvemonkeys.lang;