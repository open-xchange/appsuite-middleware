/**
 * Classes for image manipulation.
 * <p/>
 * See the class {@link com.twelvemonkeys.image.ImageUtil}.
 *
 * @version 1.0
 * @author <a href="mailto:harald.kuhr@gmail.com">Harald Kuhr</a>
 */
package com.twelvemonkeys.image;