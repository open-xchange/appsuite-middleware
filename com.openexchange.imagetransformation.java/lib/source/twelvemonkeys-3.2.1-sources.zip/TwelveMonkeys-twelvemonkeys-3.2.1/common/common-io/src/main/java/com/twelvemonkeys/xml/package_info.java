/**
 * Provides XML support classes.
 */
 package com.twelvemonkeys.xml;