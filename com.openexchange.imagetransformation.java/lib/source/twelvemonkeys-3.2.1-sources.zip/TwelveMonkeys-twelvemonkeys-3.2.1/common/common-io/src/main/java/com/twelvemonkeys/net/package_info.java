/**
 * Provides classes for net access.
 */
package com.twelvemonkeys.net;
