/**
 * Provides for system input and output through data streams, serialization and the file system.
 */
package com.twelvemonkeys.io;
