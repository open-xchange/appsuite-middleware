package javax.xml.stream;

public final class FactoryFinderAccessor {
	
	public static void updateStaxImplClassLoader(ClassLoader staxImplClassLoader) {
		FactoryFinder.setStaxImplClassLoader(staxImplClassLoader);
	}
	
}
