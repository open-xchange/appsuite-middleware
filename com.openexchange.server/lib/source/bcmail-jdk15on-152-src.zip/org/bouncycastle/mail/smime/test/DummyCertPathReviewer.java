package org.bouncycastle.mail.smime.test;

import org.bouncycastle.x509.PKIXCertPathReviewer;

public class DummyCertPathReviewer extends PKIXCertPathReviewer
{

}
