package org.jolokia.it;

/**
* @author roland
* @since 26.02.13
*/
public enum Chili {
    JOLOKIA,
    AJI,
    FATALII
}
