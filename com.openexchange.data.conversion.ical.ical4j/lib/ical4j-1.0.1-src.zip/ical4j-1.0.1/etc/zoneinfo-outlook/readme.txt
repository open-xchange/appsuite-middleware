
Please see the ical4j-zoneinfo-outlook sub-project for Outlook-compatible timezone definitions.