package jonelo.jacksum.adapt.org.bouncycastle.crypto;

/**
 * all parameter classes implement this.
 */
public interface CipherParameters
{
}
