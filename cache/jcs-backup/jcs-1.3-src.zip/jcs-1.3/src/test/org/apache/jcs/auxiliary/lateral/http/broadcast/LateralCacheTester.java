package org.apache.jcs.auxiliary.lateral.http.broadcast;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/**
 * @author Aaron Smuts
 * @created January 15, 2002
 * @version 1.0
 */
public class LateralCacheTester
{

    //    /** Description of the Method */
    //    public static void main( String args[] )
    //    {
    //
    //        String[] servers = {"10.1.17.109", "10.1.17.108"};
    //
    //        try
    //        {
    //
    //            //for ( int i=0; i <100; i++ ) {
    //            String val = "test object value";
    //            LateralCacheThread dct = new LateralCacheThread( "testTable", "testkey",
    // val, servers );
    //            dct.setPriority( Thread.NORM_PRIORITY - 1 );
    //            dct.start();
    //
    //            String val2 = "test object value2";
    //            LateralCacheThread dct2 = new LateralCacheThread( "testTable", "testkey",
    // val, servers );
    //            dct2.setPriority( Thread.NORM_PRIORITY - 1 );
    //            dct2.start();
    //            //}
    //
    //        }
    //        catch ( Exception e )
    //        {
    //            System.out.println( e.toString() );
    //        }
    //
    //    }

}
// end class
