/**
 * Contains miscellaneous utility classes.
 */
package ezvcard.util;