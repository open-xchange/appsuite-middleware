/**
 * Contains classes related to vCard parameters. 
 */
package ezvcard.parameter;