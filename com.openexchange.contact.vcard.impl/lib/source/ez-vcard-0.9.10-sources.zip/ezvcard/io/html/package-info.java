/**
 * Contains classes that can read/write hCards (HTML-encoded vCards).
 */
package ezvcard.io.html;