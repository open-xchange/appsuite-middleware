/**
 * Contains classes that know how to marshal and unmarshal a property in each vCard format. 
 */
package ezvcard.io.scribe;