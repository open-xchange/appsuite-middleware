/**
 * Contains classes that can read/write traditional, plain-text vCards.
 */
package ezvcard.io.text;