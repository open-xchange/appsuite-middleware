/**
 * Contains I/O related classes.
 */
package ezvcard.io;