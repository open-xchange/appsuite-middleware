package test3;

public class Mods {
    public int foo;
}

interface Mods2 {
    int foo();
}
