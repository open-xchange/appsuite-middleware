package test4;

public class GetFieldDesc {
    public int f;
    public String s;
}

class GetFieldDescSub extends GetFieldDesc {
    public int f;
    public int s;
}
