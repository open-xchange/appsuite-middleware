package test4;

public abstract class CtArrayTest {
}
