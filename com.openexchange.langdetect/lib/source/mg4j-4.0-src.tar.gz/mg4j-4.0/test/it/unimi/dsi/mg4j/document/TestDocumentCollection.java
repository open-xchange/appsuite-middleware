package it.unimi.dsi.mg4j.document;

import org.apache.commons.configuration.ConfigurationException;

public class TestDocumentCollection extends StringArrayDocumentCollection {
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("hiding")
	public final static String[] document = new String[] {
			"The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicenses are intended to guarantee your freedom to share and change\nfree software--to make sure the software is free for all its users.",
			" This license, the Lesser General Public License, applies to some\nspecially designated software packages--typically libraries--of the\nFree Software Foundation and other authors who decide to use it.  You\ncan use it too, but we suggest you first think carefully about whether\nthis license or the ordinary General Public License is the better\nstrategy to use in any particular case, based on the explanations below.",
			"\tWhen we speak of free software, we are referring to freedom of use,\nnot price.  Our General Public Licenses are designed to make sure that\nyou have the freedom to distribute copies of free software (and charge\nfor this service if you wish); that you receive source code or can get\nit if you want it; that you can change the software and use pieces of\nit in new free programs; and that you are informed that you can do\nthese things.",
			"To protect your rights, we need to make restrictions that forbid\ndistributors to deny you these rights or to ask you to surrender these\nrights.  These restrictions translate to certain responsibilities for\nyou if you distribute copies of the library or if you modify it.",
			"For example, if you distribute copies of the library, whether gratis\nor for a fee, you must give the recipients all the rights that we gave\nyou.  You must make sure that they, too, receive or can get the source\ncode.  If you link other code with the library, you must provide\ncomplete object files to the recipients, so that they can relink them\nwith the library after making changes to the library and recompiling\nit.  And you must show them these terms so they know their rights.",
	
	};
	
	public TestDocumentCollection() throws ConfigurationException {
		super( document ); 
	}

	public TestDocumentCollection( final String uris ) throws ConfigurationException {
		super( Boolean.parseBoolean( uris ), document ); 
	}
}
