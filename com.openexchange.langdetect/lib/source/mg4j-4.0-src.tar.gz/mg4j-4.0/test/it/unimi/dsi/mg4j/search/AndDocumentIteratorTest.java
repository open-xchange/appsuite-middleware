package it.unimi.dsi.mg4j.search;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class AndDocumentIteratorTest {

	@Test
	public void testExtentDocumentIterator() throws IOException {
		IntArrayDocumentIterator i0 = new IntArrayDocumentIterator( new int[] { 0, 1, 2 }, 
				new int[][][] { 
				{ { 0, 1 }, { 1, 2 } }, 
				{ { 0, 1 }, { 1, 2 } }, 
				{ { 1 }, { 2 } }, 
				} );
		IntArrayDocumentIterator i1 = new IntArrayDocumentIterator( new int[] { 0, 1, 2 }, 
				new int[][][] { 
				{ { 5, 7 } }, 
				{ {} }, 
				{ { 2 }, { 3 }, { 4 } }, 
				} );
		
		DocumentIterator consecutiveDocumentIterator = AndDocumentIterator.getInstance( i0, i1 );
		assertEquals( 0, consecutiveDocumentIterator.nextDocument() );
		assertEquals( 5, consecutiveDocumentIterator.intervalIterator().extent() );
		assertEquals( 1, consecutiveDocumentIterator.nextDocument() );
		assertEquals( 2, consecutiveDocumentIterator.intervalIterator().extent() );
		assertEquals( 2, consecutiveDocumentIterator.nextDocument() );
		assertEquals( 2, consecutiveDocumentIterator.intervalIterator().extent() );
	}

}
