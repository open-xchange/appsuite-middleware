#!/bin/sh

src/bin/build.sh "$@"
