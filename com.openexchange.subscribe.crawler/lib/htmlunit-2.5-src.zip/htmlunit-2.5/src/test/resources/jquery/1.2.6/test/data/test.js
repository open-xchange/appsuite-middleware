var foobar = "bar";
$('#ap').html('bar');
ok( true, "test.js executed");
