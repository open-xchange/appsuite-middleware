package org.ho.yaml.tests;

public class PDG {
   public String cacheline;
   public Node[] nodes;
   public UnionSet context;
   
   public array[] arrays;
	
}