package org.ho.yaml.tests;

public class array {
	   public int[]        dims;
	   public String       name;
	}
